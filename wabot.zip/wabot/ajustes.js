const ajustes = {
  prefijo: "/",
  wm: "Wabot",
  creador: "Azami",
  owner: "5217294888993"
}

global.ajustes = ajustes