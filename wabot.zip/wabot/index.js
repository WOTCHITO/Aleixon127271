require("./ajustes.js"); 
const { default: makeWASocket, MessageType, Presence, MessageOptions,  downloadContentFromMessage, Mimetype, useMultiFileAuthState, DisconnectReason, delay } = require("@whiskeysockets/baileys"); 
const fs = require("fs"); 
const P = require("pino"); 
const fetch = require("node-fetch"); 
const chalk = require("chalk"); 
const { color } = require("./lib/cores"); 
const { banner, getBuffer, getExtension, getRandom } = require("./lib/inicio"); 
const speed = require("performance-now"); 
const _ = require("lodash"); 

prefijo = ajustes.prefijo; 
wm = ajustes.wm; 
creador = ajustes.creador; 
owner = ajustes.owner; 

const girastamp = speed(); 
const latensi = speed() - girastamp; 

const vcard = "BEGIN:VCARD\n"; 
+ "VERSION:3.0\n"; 
+ "FN:Wabot\n"; 
+ "ORG:Curiosity Team;\n"; 
+ "TEL;type=CELL;type=VOICE;waid=5217294888993:+52 1 729 4888 993\n"; 
+ "END:VCARD"; 

async function laur() {

const { state, saveCreds } = await useMultiFileAuthState("./sessions"); 
console.log(banner.string); 
console.log(); 
const conn = makeWASocket({
logger: P({ level: "silent"}),
auth: state,
printQRInTerminal: true
}); 

conn.ev.on("creds.update", saveCreds); 
conn.ev.on("messages.upsert", async ({ messages }) => {
try {
const info = messages[0]; 
if (!info.message) return; 
await conn.readMessages([info.key.id]); 
if (info.key && info.key.remoteJid == "status@broadcast") return; 
const altpdf = Object.keys(info.message); 
const type = altpdf[0] == "senderKeyDistributionMessage" ? altpdf[1] == "messageContextInfo" ? altpdf[2] : altpdf[1] : altpdf[0]; 

const content = JSON.stringify(info.message); 
const from = info.key.remoteJid; 

var body = (type === "conversation") ?
info.message.conversation : (type == "imageMessage") ?
info.message.imageMessage.caption : (type == "videoMessage") ?
info.message.videoMessage.caption : (type == "extendedTextMessage") ?
info.message.extendedTextMessage.text : ""

const args = body.trim().split(/ +/).splice(1); 
const isCmd = body.startsWith(prefijo); 
const comando = isCmd ? body.slice(1).split(/ +/).shift().toLowerCase() : null; 

bidy =  body.toLowerCase(); 

const getFileBuffer = async (mediakey, MediaType) => { 
const stream = await downloadContentFromMessage(mediakey, MediaType); 

let buffer = Buffer.from([]); 
for await(let chunk of stream) {
buffer = Buffer.concat([buffer, chunk]); 
}; 
return buffer; 
}; 

const isGroup = from.endsWith("@g.us")
const tescuk = ["0@s.whatsapp.net"]
const sender = isGroup ? info.key.participant : from
const testat = bidy
const pushname = info.pushName ? info.pushName : ""
const groupMetadata = isGroup ? await conn.groupMetadata(from) : ""
const groupName = isGroup  ? groupMetadata.subject : ""
const groupDesc = isGroup ? groupMetadata.desc : ""
const groupMembers = isGroup ? groupMetadata.participants : ""
const groupAdmins = isGroup ? _.map(_.filter(groupMembers, "admin"), "id")  : ""
const q = args.join(" ")

const quoted = info.quoted ? info.quoted : info
const mime = (quoted.info || quoted).mimetype || ""
const owner = conn.user.id.split(":")[0] + "@s.whatsapp.net"
const isBot = info.key.fromMe
const isOwner = sender.includes(owner)
const isBotGroupAdmins = groupAdmins.includes(owner) || false
const isGroupAdmins = groupAdmins.includes(sender) || false 
const enviar = (texto) => {
conn.sendMessage(from, { text: texto }, {quoted: info}) }


if (!isCmd && !isBot) {

console.log(chalk.gray("~>"), `[${chalk.blue('Mensagem')}]`, "de", color(sender.split("@")[0]))

} else if (isCmd && !isBot) {

console.log(chalk.gray("~>"), `[${chalk.red("Comando")}]`, color(comando), "de",
color(sender.split("@")[0]))
}

switch (comando) {

// Feito por Ton

case "programado":
case "suporte":
case "dono":
await delay(3000)
try {
conn.sendMessage(sender, { contacts: { displayName: `${creador}`, contacts: [{ vcard }]
}})
} catch (e) {
console.log(e)
}
break

case "tag":
case "hidetag":
if (!isGroup) return enviar("⚠️ Este comando solo es para grupos!!.")
if (!isGroupAdmins) return enviar("⚠️ Somente admins pueden utilizar este comando.")
if (args.length < 1) return enviar("Ingresa un texto")
let mem = _.map(groupMembers, "id")
let options = {
  text: q,
  mentions: mem,
  quoted: info
}
conn.sendMessage(from, options)
break

case "reagir":
{
conn.sendMessage(from, { react: { text: "🍰", key: info.key }})
}
break

case "ping":
enviar(`🍧 Velocidad: ${latensi.toFixed(4)}`)
break

case 'update': case `actualizar`:
if (!isOwner) return conn.sendMessage(from, { text: `*ESTE COMANDO ES PARA MI JEFE*` }, { quoted: from });    
try {    
let stdout = execSync('git pull' + (m.fromMe && q ? ' ' + q : ''))
await conn.sendMessage(from, { text: stdout.toString() }, { quoted:  from});
} catch { 
let updatee = execSync('git remote set-url origin https://github.com/AzamiJs/Azamijs.git && git pull')
await conn.sendMessage(from, { text: updatee.toString() }, { quoted:  from})}  
break

default:

switch (testat) {

case "Yaoi":
enviar("😻")
break

case "wabot":
conn.sendMessage(from, { react: { text: "🍰", key: info.key }})
break

case "menu":
enviar("Wabot simple\n\n• /hidetag\n• /ping\n• /update")
break

}

if (isCmd) {
enviar("🧃 No se encontró el comando")
}

}

} catch (e) {
console.log(e)
}})

conn.ev.on("connection.update", (update) => {
let { connection, lastDisconnect } = update

if (connection === "open") {
console.log(chalk.greenBright("Conectado ✓"))
console.log(chalk.gray("Info"), color("Baileys"))
console.log(chalk.gray("Info"), color("Wabot"))
console.log()
} else if (connection === "close") {

console.log(chalk.gray("Conexión mala"))
laur()
}
if(update.isNewLogin) {
laur()
}})}
laur()