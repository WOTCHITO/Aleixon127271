apt-get update -y

apt-get upgrade -y

apt-get install nodejs  -y

apt-get install libwebp -y

npm i 

sh start.sh