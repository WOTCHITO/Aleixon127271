while :
do
      node index.js
      sleep 1
      
done

#sistema para o bot não cair
# de sh akame.sh no termux!!