const figurinhas =(p) =>{
return`
╭⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤
≑ ↳  ❗STICKER❗
↳.....................................
≑ ⇢  ${p}Fig
≑ ⇢  ${p}Attp
≑ ⇢  ${p}Toimg
╰⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤`}
exports.figurinhas = figurinhas

const criador = (p)=> {
return`
╭⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤
⎧......................................
≑ ↳  ❗CRIADOR❗
↳.....................................
≑ ⇢  ${p}Aviso
≑ ⇢  ${p}Rename
≑ ⇢  ${p}Setprefix
╰⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤`}
exports.criador = criador 